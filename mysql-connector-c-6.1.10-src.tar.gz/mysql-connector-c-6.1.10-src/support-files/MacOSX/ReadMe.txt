
You can find information about how to install on Mac OS X at

  http://dev.mysql.com/doc/refman/5.1/en/mac-os-x-installation.html

The MySQL Reference Manual is also available in various formats on
http://dev.mysql.com/doc; if you're interested in the DocBook XML
sources go to http://svn.mysql.com.
